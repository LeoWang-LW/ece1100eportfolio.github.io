Drop your photos in this folder with these exact file names and they appear on the site automatically.
Until a file exists, its slot stays hidden.

headshot.jpg      Home page, next to the welcome statement
keychain-pcb.jpg  About page and Projects page (HyTech keychain PCB)
robot-tour.jpg    About page and Projects page (Science Olympiad robot)
ftc-robot.jpg     Projects page (FTC robot)
